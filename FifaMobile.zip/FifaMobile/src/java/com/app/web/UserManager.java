/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.web;

import com.app.dao.DAOUser;
import com.app.models.User;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 *
 * @author Profesormanana
 */
@Named("um")
@ApplicationScoped
public class UserManager implements Serializable {

    
    private String username, email, password, mensaje;
    private boolean logeado;
    private final DAOUser dao;

    public UserManager() {
        dao = new DAOUser();
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isLogeado() {
        return logeado;
    }

    public void setLogeado(boolean logeado) {
        this.logeado = logeado;
    }

    public String entrar() {
        if(this.username.equals("admin") && this.password.equals("1234")){
            logeado=true;
        }
        return "show";
    }
    public String reset() {
        this.username="";
        this.password="";
        this.email="";
        this.mensaje="";
           
        return "index";
    }
    public String create(){
        dao.grabar(new User(username, email, password));
        mensaje = "Usuario creado con exito";
        return "index";
    }

    
}
