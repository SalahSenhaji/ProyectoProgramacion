
public enum TipoStaff {

    operaciones,
    administrativo,
    tecnico;
}
