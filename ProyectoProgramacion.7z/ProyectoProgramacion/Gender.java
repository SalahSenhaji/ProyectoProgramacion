
public enum Gender {
    masculino,
    femenino;
}
