public class Enfermera extends Staff {

    public Enfermera(String fechaIngreso, String estudios, String idiomas, TipoStaff tipoStaff,
            Departamento departamento, Persona persona) {
        super(fechaIngreso, estudios, idiomas, tipoStaff, departamento, persona);
        // TODO Auto-generated constructor stub
    }

}
